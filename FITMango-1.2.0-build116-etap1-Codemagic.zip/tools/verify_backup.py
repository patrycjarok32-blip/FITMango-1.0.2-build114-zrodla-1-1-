#!/usr/bin/env python3
"""Read-only FITMango v1 archive validation (does not restore into Android)."""
import hashlib, json, re, sys, zipfile
from pathlib import Path

def validate(path):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        assert len(names)==len(set(names)), "Duplicate archive entries"
        assert "backup.json" in names, "Missing backup.json"
        assert all(n=="backup.json" or re.fullmatch(r"assets/\d+\.bin", n) for n in names), "Unexpected archive entry"
        manifest=json.loads(z.read("backup.json"))
        assert manifest.get("format")=="FITMango" and manifest.get("version")==1, "Unsupported backup format"
        assert manifest.get("schema") in (8,9), "Unsupported backup schema"
        assets=manifest.get("assets",{})
        expected={v["name"] for v in assets.values()}
        assert set(names)==expected|{"backup.json"}, "Asset list mismatch"
        for asset in assets.values():
            payload=z.read(asset["name"])
            assert len(payload)==asset["size"], "Asset size mismatch"
            assert hashlib.sha256(payload).hexdigest().lower()==asset["sha256"].lower(), "Asset hash mismatch"
        print(f"PASS: FITMango backup schema {manifest['schema']}, {len(assets)} verified assets")
        print("Note: archive validation does not prove successful restore on Android.")

if __name__=="__main__":
    validate(Path(sys.argv[1]))
