package com.example.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Central FITMango design tokens. Keep semantic roles shared by every screen. */
object MangoAppearance {
    var light by mutableStateOf(false)
    const val PREFS = "FITMangoUsability"
    const val KEY = "lightTheme"
}

private fun role(dark: Long, light: Long) = Color(if (MangoAppearance.light) light else dark)

// Deep botanical dark theme + warm, clean light theme.
val MangoYellow get() = role(0xFFFFC857, 0xFF875600)
val JuicyOrange get() = role(0xFFF4A261, 0xFFB85B20)
val Cream get() = role(0xFFF1F6F2, 0xFF20352B)
val LeafGreen get() = role(0xFF55C995, 0xFF167653)
val DarkBackground get() = role(0xFF0B1411, 0xFFF5F8F2)
val WarmBrown get() = role(0xFF2A3B33, 0xFFD7E1D7)
val GoldAccent get() = role(0xFFA7B8AE, 0xFF61766A)
val MutedSurface1 get() = role(0xFF121F1A, 0xFFFFFFFF)
val MutedSurface2 get() = role(0xFF1A2B23, 0xFFEBF2E9)
val SurfaceDark get() = role(0xFF08100D, 0xFFEEF3EA)
val RipeYellow get() = role(0xFFFFD36E, 0xFFFFC857)
val MangoButtonInk get() = Color(0xFF14221B)
val ActivityAccent get() = LeafGreen
val SleepAccent get() = DinnerAccent
val ProteinAccent get() = LeafGreen
val CarbsAccent get() = MangoYellow
val FatAccent get() = role(0xFFFF79AC, 0xFFB31867)
val WaterAccent get() = role(0xFF67B7FF, 0xFF1768AB)
val DinnerAccent get() = role(0xFFB9A0FF, 0xFF694BA6)
val OrangeInk get() = role(0xFFFFC078, 0xFF95501B)
val Pistachio get() = Color(0xFFA5D6A7)
val ErrorInk get() = role(0xFFFF9299, 0xFFB3261E)
