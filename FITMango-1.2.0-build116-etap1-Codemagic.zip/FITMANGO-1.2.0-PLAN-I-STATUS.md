# FITMango 1.2.0 (build 116) — etap 1 / projekt źródłowy

## Zrealizowane w tej paczce
- Wersja Android: versionCode 116, versionName 1.2.0.
- Dodatkowe podsumowanie pomiarów w istniejącym ekranie Postępy (ostatnia waga, średnia z 7 ostatnich pomiarów, zmiana od pierwszego).
- Zachowana baza Room w wersji 9 i format kopii FITMango v1 / schemat 8–9. Nie wprowadzono nieprzetestowanej migracji.
- Narzędzie `tools/verify_backup.py` do sprawdzania archiwum i SHA-256 załączników.
- `codemagic.yaml` do budowy testowego APK na mac_mini_m2.

## Funkcje już obecne w kodzie bazowym (wymagają audytu i testów)
- Ekran skanera kodów, przepisy i ulubione, planer, wykres wagi, przypomnienia, obsługa zdjęć i Gemini, ustawienia wyglądu, kopie zapasowe.

## Do wdrożenia w następnych etapach — NIE GOTOWE
1. Integracja skanera z wiarygodną bazą wartości odżywczych i ręczną korektą.
2. Kompletny dziennik kalorii i makroskładników, zapis danych i ich eksport.
3. Zaawansowane wykresy obwodów i zakresy czasowe.
4. Generowanie tygodniowego planu AI z zatwierdzaniem i walidacją.
5. Szacowanie wartości posiłków ze zdjęć, zgody i korekty.
6. Audyt powiadomień i ulubionych.
7. Pełne testy jasnego/ciemnego motywu.
8. Rozszerzenie schematu i backupu dopiero łącznie z migracją Room oraz testem przywracania.

## Bezpieczeństwo
- Nie instaluj debug APK jako aktualizacji build 109: podpis może być inny.
- Klucz debugowy jest tymczasowy i generowany na każdej maszynie; nie używać go do wydania produkcyjnego.
- Przed migracją zachowaj oryginalną kopię ZIP poza telefonem.
- Nie wgrywaj keystore ani haseł do GitHub. Użyj bezpiecznych sekretów Codemagic dla wydania produkcyjnego.
- NIE potwierdzono kompilacji Gradle ani testu przywracania na Androidzie w tym środowisku.
