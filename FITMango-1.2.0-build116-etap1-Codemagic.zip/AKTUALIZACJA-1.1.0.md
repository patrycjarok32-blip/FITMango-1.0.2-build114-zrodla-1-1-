# FITMango 1.1.0 / build 115

## Zmiany w źródłach
- Odświeżona paleta jasnego i ciemnego motywu: botaniczna zieleń, cieplejsze akcenty, kontrastowe tła.
- Delikatnie zaokrąglone karty i dolny pasek nawigacji, bardziej czytelny stan wybranej zakładki.
- Uproszczony podtytuł ekranu startowego.
- Wersja Android: `versionCode=115`, `versionName=1.1.0`.
- Dodany `codemagic.yaml`: testy jednostkowe, lint, budowa podpisanego APK i AAB, kontrola wersji.

## Zachowanie danych
Nie zmieniono `applicationId`, schematu Room ani migracji. Nie zmieniono mechanizmu backupu, integracji AI, Health Connect ani Renpho. Aktualizacja istniejącej instalacji wymaga **tego samego klucza podpisu**. Zachowaj kopię zapasową przed instalacją.

## Konfiguracja Codemagic
1. Wgraj **rozpakowane źródła** do głównego katalogu repozytorium razem z `codemagic.yaml` (nie wgrywaj samego ZIP-a bez rozpakowania).
2. W Codemagic podłącz repozytorium i wybierz workflow `fitmango-1-1-0-build115`.
3. W grupie środowiskowej `fitmango_signing` skonfiguruj **sekretne** `FITMANGO_KEYSTORE_BASE64` (Base64 istniejącego klucza `.jks`), `STORE_PASSWORD`, `KEY_PASSWORD`. `KEY_ALIAS` jest opcjonalne (domyślnie `upload`).
4. Uruchom workflow; podpisane APK/AAB będą dostępne w artefaktach dopiero po przejściu testów i lint.

## Status weryfikacji
Zmiany źródłowe i konfiguracja są przygotowane. Kompilacja Android, testy oraz lint **nie zostały uruchomione pomyślnie lokalnie**; nie twierdzimy, że APK zostało zbudowane. Workflow wymaga dostępu do zależności Gradle, SDK Android i dotychczasowego klucza podpisu. Przed instalacją przetestuj aktualizację na kopii urządzenia/danych.
